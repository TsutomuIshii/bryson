<?php

ini_set("display_errors", On);
error_reporting(E_ALL);

	//ユーザーネーム	TestAwsUser
	//アクセスキー　　　AKIAIA6KSAWPQZHSEWJQ
	//シークレットキー　iL4Q3qBlYRO1CQVuc2BPX9MGWiMIu/XPw3wIVib/


	// AWS SDK for PHP 2を読み込む
	require_once './aws.phar';
	 
	use Aws\Ses\SesClient as SesClient;
	use Aws\Common\Enum\Region as Region;
	use Aws\Ses\Exception\SesException as SesException;
	 
	$aws_access_key = "AKIAIA6KSAWPQZHSEWJQ";    // アクセスキー
	$aws_secret_key = "iL4Q3qBlYRO1CQVuc2BPX9MGWiMIu/XPw3wIVib/";    // シークレットキー
	 
	$source = 'tishii@brycen.co.jp';    //送信元アドレス
	$dest = 'tishii@brycen.co.jp';    //送信先アドレス
	$charset = 'ISO-2022-JP';   //変換先の文字コード
	 
	$subject = "SESサンプルメール";     //件名
	$body_text = "サンプルメールです。\n";    //本文
	$body_text = $body_text."2行目です\n";    //本文
	 
	try {
	    //アクセスキー、シークレットキー、リージョンを指定しクライアントを生成する
	    $client = SesClient::factory(
	                    array(
	                        'key' => $aws_access_key,
	                        'secret' => $aws_secret_key,
	                        'region' => Region::OREGON
	                    )
	    );
	 
	    //添付ファイル無しのメールを送信
	    $result = $client->sendEmail(array(
	        // Source（送信元）は必須
	        'Source' => $source,
	        // Destination（宛先）は必須
	        'Destination' => array(
	            'ToAddresses' => array($dest), // To
	            'CcAddresses' => array(), // CC(あれば)
	            'BccAddresses' => array(), // BCC(あれば)
	        ),
	        // Message（メッセージ部分）は必須
	        'Message' => array(
	            // Subject（件名）は必須
	            'Subject' => array(
	                // Data（件名部分データ）は必須
	                'Data' => $subject,
	                'Charset' => $charset,
	            ),
	            // Body（本文）は必須
	            'Body' => array(
	                'Text' => array(
	                    // Data（本文データ）は必須
	                    'Data' => $body_text,
	                    'Charset' => $charset,
	                ),
	            /* HTMLメールを送る場合
	              'Html' => array(
	              // Data（HTMLデータ）は必須
	              'Data' => 'HTMLです',
	              'Charset' => $charset,
	              ),
	             */
	            ),
	        ),
	            )
	    );
	 
	$message = "メール送信が完了しました。";

	    // 結果を表示
	    echo '<pre>';
	    print_r($message."\n\n".$result);
	    echo '</pre>';
	     
	} catch (SesException $exc) {
	    echo $exc->getMessage();
	}
?>
